# YT-simple-portfolio
### A simple one-page portfolio that consists of a personal image, description and your social links. It's a challenge from the [frontendmentor.io](https://www.frontendmentor.io/challenges)

- Check the challenge page [here](https://www.frontendmentor.io/challenges/coding-bootcamp-testimonials-slider-4FNyLA8JL)
- Check the youtube video of making this website [here](https://www.youtube.com/watch?v=DUkwBMyCcHY)
- Check the live website [here](http://mohamedabusrea.netlify.app/)
